﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Member_Default : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("~/Account/Login.aspx");
        }

        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.AddInsurances.ToList();
            DropDownList1.DataTextField = "Type";
            DropDownList1.DataValueField = "Type";
            DropDownList1.DataBind();

        }
        var data = db.AddInsurances.ToList();
        GridView1.DataSource = data;
        GridView1.DataBind();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            //int x = Int32.Parse(DropDownList1.SelectedValue);
            var data = db.AddInsurances.Where(d => d.Type.Contains(DropDownList1.SelectedValue)).ToList();

            GridView1.DataSource = data;
            GridView1.DataBind();
        }
        catch (Exception)
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Please Type ID!!!')", true);

        }
    }
}