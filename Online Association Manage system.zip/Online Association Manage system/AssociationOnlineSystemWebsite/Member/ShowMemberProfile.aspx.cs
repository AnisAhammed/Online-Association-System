﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Member_ShowMemberProfile : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("~/Account/Login.aspx");
        }
        string username = Session["un"].ToString();
        var data = db.Members.Where(d => d.UserName == username).FirstOrDefault();

        if (data != null)
        {
            lblMemberId.Text = data.MemberId.ToString();
            lblFirstName.Text = data.FirstName;
            lblLastName.Text = data.LastName;
            lblFatherName.Text = data.FatherName;
            lblMotherName.Text = data.MotherName;
            lblDOB.Text = ((DateTime)data.DOB).ToString("yyyy / MM / dd");
            lblGender.Text = data.Gender;
            Image1.ImageUrl = "../Upload/" + data.Photo;
            lblNIdNo.Text = data.NIdNo;
            lblPhoneNo.Text = data.Phone;
            lblAddress.Text = data.Address;
            lblBranchId.Text = data.BranchId.ToString();
        }
    }

    protected void btnProfile_Click(object sender, EventArgs e)
    {

    }
}