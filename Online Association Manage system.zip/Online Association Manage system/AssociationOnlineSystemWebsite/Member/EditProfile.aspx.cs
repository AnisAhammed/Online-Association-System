﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Member_EditProfile : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
               
                string username = Session["un"].ToString();
                var data = db.Members.Where(d => d.UserName == username).FirstOrDefault();

                if (data != null)
                {
                    
                    txtFirstName.Text = data.FirstName;
                    txtLastName.Text = data.LastName;
                    txtFatherName.Text = data.FatherName;
                    txtMotherName.Text = data.MotherName;
                    txtDOB.Text = ((DateTime)data.DOB).ToString("yyyy / MM / dd");
                    txtPhone.Text = data.Phone;
                    Image1.ImageUrl = "../Upload/" + data.Photo;
                    txtNationalIdNo.Text = data.NIdNo;
                    txtPhone.Text = data.Phone;
                    txtAddress.Text = data.Address;


                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            string username = Session["un"].ToString();
            var data = db.Members.Where(d => d.UserName == username).FirstOrDefault();

            if (data != null)
            {
                data.FirstName = txtFirstName.Text;
                data.LastName = txtLastName.Text;
                data.FatherName = txtFatherName.Text;
                data.MotherName = txtMotherName.Text;
                data.DOB = DateTime.Parse(txtDOB.Text);

                if (FileUpload1.HasFile)
                {
                    string extension = System.IO.Path.GetExtension(FileUpload1.FileName);

                    Session["Pic"] = FileUpload1.FileName;

                    if (extension == ".jpg" || extension == ".gif")
                    {
                        if (FileUpload1.PostedFile.ContentLength < (500 * 1024))
                        {
                           
                            FileUpload1.SaveAs(Server.MapPath("../Upload/") + Session["pic"]);

                            Image1.ImageUrl = "../Upload/" + Session["pic"];
                            data.Photo = FileUpload1.FileName;
                        }
                        else
                        {
                            Literal1.Text = "<script>alert('Please select below 500 Kb !!!');</script>";
                            return;
                        }
                    }
                    else
                    {
                        Literal1.Text = "<script>alert('Please select jpg or gif file !!!');</script>";
                        return;
                    }

                }
                data.NIdNo = txtNationalIdNo.Text;
                data.Phone = txtPhone.Text;
                data.Address = txtAddress.Text;


                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);

                txtFirstName.Text = "";
                txtLastName.Text = "";
                txtFatherName.Text = "";
                txtMotherName.Text = "";
                txtDOB.Text = "";
                txtNationalIdNo.Text = "";
                Image1.ImageUrl = "";
                txtPhone.Text = "";
                txtAddress.Text = "";
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }   
}