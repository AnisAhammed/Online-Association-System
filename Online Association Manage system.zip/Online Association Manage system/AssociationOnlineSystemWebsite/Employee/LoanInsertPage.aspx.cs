﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_LoanInsertPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("./Default.aspx");
        }
        

        if (!IsPostBack)
        {
            DropDownList2.DataSource = db.Members.Where(m => m.Status != "Not Approved").ToList();
            DropDownList2.DataTextField = "FirstName";
            DropDownList2.DataValueField = "MemberId";
            DropDownList2.DataBind();

            txtLoanDate.Text = DateTime.Now.ToShortDateString();
        }
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        try
        {
            Loan ln = new Loan();

            ln.LoanAmount = decimal.Parse(txtLoanAmount.Text);
            ln.InstallmentNo = Int32.Parse(lblInstallmentNo.Text);
            ln.InstallmentAmount = decimal.Parse(txtInstallmentAmount.Text);
            ln.LoanDate = DateTime.Parse(txtLoanDate.Text);
            ln.Status = lblStatus.Text;
            ln.MemberId = Int32.Parse(DropDownList2.SelectedValue);

            ln.UserName = Session["un"].ToString();

            db.Loans.Add(ln);
            db.SaveChanges();

            lblLoanId.Text = ln.LoanId.ToString();

            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Save Successfully!!!')", true);

            lblLoanId.Text = "";
            txtLoanDate.Text = "";
            txtInstallmentAmount.Text = "";
            lblInstallmentNo.Text = "";
            txtLoanAmount.Text = "";
            lblStatus.Text = "";
            DropDownList2.SelectedIndex = -1;
        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Int32.Parse(DropDownList2.SelectedValue);
        var data = db.Members.Where(d => d.MemberId == id).FirstOrDefault();

        if (data != null)
        {
            lblId.Text = id.ToString();
            lblFirstName.Text = data.FirstName + " " + data.LastName;
            lblPhoneNo.Text = data.Phone;
            Image1.ImageUrl = "../Upload/" + data.Photo;
        }
    }

    protected void txtLoanAmount_TextChanged(object sender, EventArgs e)
    {
        try
        {
            txtInstallmentAmount.Text = (((Int32.Parse(txtLoanAmount.Text) * 15 / 100) + (Int32.Parse(txtLoanAmount.Text))) / 46).ToString();
        }
        catch (Exception)
        {

            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Please Loan Amount Input number!!!')", true);
        }
    }
}