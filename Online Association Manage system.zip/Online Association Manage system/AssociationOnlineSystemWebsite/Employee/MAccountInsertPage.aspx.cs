﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_MAccountInsertPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("./Default.aspx");
        }

        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Members.Where(m => m.Status != "Not Approved").ToList();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "MemberId";
            DropDownList1.DataBind();            
        }

    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        
        try
        {         

                MAccount mat = new MAccount();

                mat.AccountNo = Int32.Parse(txtAccountNo.Text);
                mat.Balance = decimal.Parse(lblBalance.Text);
                mat.StartDate = DateTime.Parse(txtStartDate.Text);
                mat.Status = lblStatus.Text;
                mat.MemberId = Int32.Parse(DropDownList1.SelectedValue);

                mat.UserName = Session["un"].ToString();

                db.MAccounts.Add(mat);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Save Successfully!!!')", true);

                txtAccountNo.Text = "";
                lblBalance.Text = "";
                txtStartDate.Text = "";
                DropDownList1.SelectedIndex = 0;

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;
        }
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Int32.Parse(DropDownList1.SelectedValue);
        var data = db.Members.Where(d => d.MemberId == id).FirstOrDefault();

        if (data != null)
        {
            lblId.Text = id.ToString();
            lblFirstName.Text = data.FirstName + " " + data.LastName;
            lblPhoneNo.Text = data.Phone;
            Image1.ImageUrl = "../Upload/" + data.Photo;
        }
    }
}