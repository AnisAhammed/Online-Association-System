﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Member_ShowMemberProfile : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("~/Account/Login.aspx");
        }
        string username = Session["un"].ToString();
        var data = db.Employees.Where(d => d.UserName == username).FirstOrDefault();

        if (data != null)
        {
            lblEmployeeId.Text = data.EmployeeId.ToString();
            lblName.Text = data.Name;
            lblJoinDate.Text = ((DateTime)data.JoinDate).ToString("yyyy / MM / dd");
            Image1.ImageUrl = "../Upload/" + data.Photo;
            lblPhoneNo.Text = data.Phone;
            lblAddress.Text = data.Address;
            lblSalary.Text = ((decimal)data.Salary).ToString(".00");
        }
    }

    protected void btnProfile_Click(object sender, EventArgs e)
    {

    }
}