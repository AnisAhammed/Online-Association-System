﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Member_ChangePassword : System.Web.UI.Page
{

    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string username = Session["un"].ToString();
        var data = db.Users.Where(d => d.UserName == username && d.Password== txtCurrentPassword.Text).FirstOrDefault();

        if (data != null)
        {
            data.Password = txtNewPassword.Text;
            db.SaveChanges();
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Wrong current Password!!!')", true);

        }
    }
}