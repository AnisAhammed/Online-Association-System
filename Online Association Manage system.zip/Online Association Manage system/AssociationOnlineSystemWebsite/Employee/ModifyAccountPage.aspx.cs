﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifyAccountPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            DropDownList2.DataSource = db.Members.ToList();
            DropDownList2.DataTextField = "FirstName";
            DropDownList2.DataValueField = "MemberId";
            DropDownList2.DataBind();

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.MAccounts.Where(d => d.AccountNo == idn).FirstOrDefault();

                if (data != null)
                {
                    txtAccountNo.Text = idn.ToString();
                    txtBalance.Text = ((decimal)data.Balance).ToString(".00");                    
                    txtStartDate.Text = ((DateTime)data.StartDate).ToString("yyyy / MM / dd");
                    lblStaus.Text = data.Status.ToString();
                    DropDownList2.SelectedValue = data.MemberId.ToString();

                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtAccountNo.Text);
        var data = db.MAccounts.Where(d => d.AccountNo == x).FirstOrDefault();

        if (data != null)
        {
            txtBalance.Text = data.Balance.ToString();
            txtStartDate.Text = data.StartDate.ToString();
            lblStaus.Text = data.Status.ToString();
            DropDownList2.SelectedValue = data.MemberId.ToString();
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtAccountNo.Text);
            var data = db.MAccounts.Where(d => d.AccountNo == x).FirstOrDefault();

            if (data != null)
            {
                data.AccountNo = Int32.Parse(txtAccountNo.Text);
                data.Balance= decimal.Parse(txtBalance.Text);
                data.StartDate = DateTime.Parse(txtStartDate.Text);
                data.Status = lblStaus.Text;
                data.MemberId = Int32.Parse(DropDownList2.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);

                txtAccountNo.Text = "";
                txtBalance.Text = "";
                txtStartDate.Text = "";
                lblStaus.Text = "";
                DropDownList2.SelectedIndex = 0;

            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtAccountNo.Text);
            var data = db.MAccounts.Where(d => d.AccountNo == x).FirstOrDefault();

            if (data != null)
            {
                db.MAccounts.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);
                txtAccountNo.Text = "";
                txtBalance.Text = "";
                txtStartDate.Text = "";
                lblStaus.Text = "";
                DropDownList2.SelectedIndex = 0;
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

}