﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_TransactionInsertPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("./Default.aspx");
        }

        if (!IsPostBack)
        {
            
            DropDownList1.DataSource = db.MAccounts.Where(m => m.Status != "Not Approved").ToList();
            DropDownList1.DataTextField = "AccountNo";
            DropDownList1.DataValueField = "AccountNo";
            DropDownList1.DataBind();

                DropDownList3.DataSource = db.Members.Where(m => m.Status != "Not Approved").ToList();
                DropDownList3.DataTextField = "FirstName";
                DropDownList3.DataValueField = "MemberId";
                DropDownList3.DataBind();
        }        
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        int acid = Int32.Parse(DropDownList1.SelectedValue);
        var data = db.MAccounts.Where(d => d.AccountNo == acid).FirstOrDefault().Balance;


        if (data - 500 > decimal.Parse(txtAmount.Text))
        {
            try
            {
                Transaction trn = new Transaction();

                trn.Amount = decimal.Parse(txtAmount.Text);
                trn.Type = DropDownList2.SelectedValue;
                trn.Date = DateTime.Parse(txtDate.Text);


                trn.AccountNo = acid;
                trn.MemberId = Int32.Parse(DropDownList3.SelectedValue);

                trn.UserName = Session["un"].ToString();

                db.Transactions.Add(trn);
                db.SaveChanges();

                lblTransactionId.Text = trn.TransactionId.ToString();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Save Successfully!!!')", true);

                lblTransactionId.Text = "";
                txtAmount.Text = "";
                DropDownList2.SelectedIndex = -1;
                txtDate.Text = "";
                DropDownList1.SelectedIndex = -1;
                DropDownList3.SelectedIndex = -1;

            }
            catch (Exception ex1)
            {

                Literal1.Text = ex1.Message;
            }
        }

        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Sorry, Not Enough Money Available')", true);
        }
        
    }

    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Int32.Parse(DropDownList3.SelectedValue);
        var data = db.Members.Where(d => d.MemberId == id).FirstOrDefault();

        if (data != null)
        {
            lblId.Text = id.ToString();
            lblFirstName.Text = data.FirstName + " " + data.LastName;
            lblPhoneNo.Text = data.Phone;
            Image1.ImageUrl = "../Upload/" + data.Photo;
        }
    }
}