﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifyLoanPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            DropDownList2.DataSource = db.Members.ToList();
            DropDownList2.DataTextField = "FirstName";
            DropDownList2.DataValueField = "MemberId";
            DropDownList2.DataBind();

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.Loans.Where(d => d.LoanId == idn).FirstOrDefault();

                if (data != null)
                {
                    txtLoanId.Text = idn.ToString();
                    txtLoanAmount.Text = ((decimal)data.LoanAmount).ToString(".00");
                    txtInstallmentNo.Text = data.InstallmentNo.ToString();
                    txtInstallmentAmount.Text = ((decimal)data.InstallmentAmount).ToString(".00");
                    txtLoanDate.Text = ((DateTime)data.LoanDate).ToString("yyyy / MM / dd");
                    DropDownList2.SelectedValue = data.MemberId.ToString();

                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtLoanId.Text);
        var data = db.Loans.Where(d => d.LoanId == x).FirstOrDefault();

        if (data != null)
        {
            txtLoanAmount.Text = data.LoanAmount.ToString();
            txtInstallmentNo.Text = data.InstallmentNo.ToString();
            txtInstallmentAmount.Text = data.InstallmentAmount.ToString();
            txtLoanDate.Text = data.LoanDate.ToString();
            DropDownList2.SelectedValue = data.MemberId.ToString();
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtLoanId.Text);
            var data = db.Loans.Where(d => d.LoanId == x).FirstOrDefault();

            if (data != null)
            {
                data.LoanId = Int32.Parse(txtLoanId.Text);
                data.LoanAmount = decimal.Parse(txtLoanAmount.Text);
                data.InstallmentNo = Int32.Parse(txtInstallmentNo.Text);
                data.InstallmentAmount = decimal.Parse(txtInstallmentAmount.Text);
                data.LoanDate = DateTime.Parse(txtLoanDate.Text);
                data.MemberId = Int32.Parse(DropDownList2.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);

                txtLoanId.Text = "";
                txtLoanAmount.Text = "";
                txtInstallmentNo.Text = "";
                txtInstallmentAmount.Text = "";
                txtLoanDate.Text = "";
                DropDownList2.SelectedIndex = -1;
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtLoanId.Text);
            var data = db.Loans.Where(d => d.LoanId == x).FirstOrDefault();

            if (data != null)
            {
                db.Loans.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);

                txtLoanId.Text = "";
                txtLoanAmount.Text = "";
                txtInstallmentNo.Text = "";
                txtInstallmentAmount.Text = "";
                txtLoanDate.Text = "";
                DropDownList2.SelectedIndex = -1;
            }

        }
        catch (Exception)
        {

            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Can not Delete!!!')", true);

        }
    }
}