﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_SavingsAccountInsertPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("./Default.aspx");
        }

        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Members.Where(m => m.Status != "Not Approved").ToList();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "MemberId";
            DropDownList1.DataBind();
        }
    }

    protected void btnInsert_Click1(object sender, EventArgs e)
    {
        try
        {
            SavingsAccount sat = new SavingsAccount();
            sat.SavingsAccountNo = Int32.Parse(txtSavingsAccountNo.Text);
            sat.TotalSavings = decimal.Parse(lblTotalSavings.Text);
            sat.SDate = DateTime.Parse(txtSavingsDate.Text);
            sat.Status = lblStatus.Text;
            sat.MemberId = Int32.Parse(DropDownList1.SelectedValue);

            sat.UserName = Session["un"].ToString();

            db.SavingsAccounts.Add(sat);
            db.SaveChanges();

        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Save Successfully!!!')", true);

        txtSavingsAccountNo.Text = "";       
        txtSavingsDate.Text = "";
        DropDownList1.SelectedIndex = 0;

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Int32.Parse(DropDownList1.SelectedValue);
        var data = db.Members.Where(d => d.MemberId == id).FirstOrDefault();

        if (data != null)
        {
            lblId.Text = id.ToString();
            lblFirstName.Text = data.FirstName + " " + data.LastName;
            lblPhoneNo.Text = data.Phone;
            Image1.ImageUrl = "../Upload/" + data.Photo;
        }
    }
}