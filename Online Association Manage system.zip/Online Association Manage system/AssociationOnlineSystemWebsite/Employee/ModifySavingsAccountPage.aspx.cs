﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifySavingsAccountPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            DropDownList2.DataSource = db.Members.ToList();
            DropDownList2.DataTextField = "FirstName";
            DropDownList2.DataValueField = "MemberId";
            DropDownList2.DataBind();
            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.SavingsAccounts.Where(d => d.SavingsAccountNo == idn).FirstOrDefault();

                if (data != null)
                {
                    txtSavingsAccountNo.Text = idn.ToString();
                    lblTotalSavings.Text = ((decimal)data.TotalSavings).ToString(".00");
                    txtSavingsDate.Text = ((DateTime)data.SDate).ToString("yyyy / MM / dd");
                    lblStatus.Text = data.Status.ToString();
                    DropDownList2.SelectedValue = data.MemberId.ToString();

                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }

        }
    }



    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtSavingsAccountNo.Text);
        var data = db.SavingsAccounts.Where(d => d.SavingsAccountNo == x).FirstOrDefault();

        if (data != null)
        {
            lblTotalSavings.Text = ((decimal)data.TotalSavings).ToString(".00");
            txtSavingsDate.Text = ((DateTime)data.SDate).ToString("yyyy / MM / dd");
            lblStatus.Text = data.Status.ToString();
            DropDownList2.SelectedValue = data.MemberId.ToString();

        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {

        try
        {
            int x = Int32.Parse(txtSavingsAccountNo.Text);
            var data = db.SavingsAccounts.Where(d => d.SavingsAccountNo == x).FirstOrDefault();

            if (data != null)
            {
                data.SavingsAccountNo = Int32.Parse(txtSavingsAccountNo.Text);
                data.TotalSavings = decimal.Parse(lblTotalSavings.Text);
                data.SDate = DateTime.Parse(txtSavingsDate.Text);
                data.Status = lblStatus.Text;
                data.MemberId = Int32.Parse(DropDownList2.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);

                txtSavingsAccountNo.Text = "";
                txtSavingsDate.Text = "";
                lblTotalSavings.Text = "";
                lblStatus.Text = "";
                DropDownList2.SelectedIndex = 0;

            }
        }

        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            try
            {
                int x = Int32.Parse(txtSavingsAccountNo.Text);
                var data = db.SavingsAccounts.Where(d => d.SavingsAccountNo == x).FirstOrDefault();

                if (data != null)
                {
                    db.SavingsAccounts.Remove(data);
                    db.SaveChanges();

                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);


                    txtSavingsAccountNo.Text = "";
                    txtSavingsDate.Text = "";
                    lblTotalSavings.Text = "";
                    lblStatus.Text = "";
                    DropDownList2.SelectedIndex = 0;
                }

            }
            catch (Exception ex1)
            {

                Literal1.Text = ex1.Message;

            }
        }
    }
}