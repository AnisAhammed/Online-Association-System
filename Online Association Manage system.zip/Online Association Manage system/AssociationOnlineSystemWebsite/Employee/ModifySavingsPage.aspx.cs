﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifySavingsPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Members.ToList();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "MemberId";
            DropDownList1.DataBind();

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.Savings.Where(d => d.SavingsId == idn).FirstOrDefault();

                if (data != null)
                {
                    txtSavingsId.Text = idn.ToString();
                    txtAmount.Text = ((decimal)data.Amount).ToString(".00");
                    DropDownList2.SelectedValue = data.Type.ToString();
                    txtDate.Text = ((DateTime)data.Date).ToString("yyyy / MM / dd");
                    DropDownList3.SelectedValue = data.SavingsAccountNo.ToString();
                    DropDownList1.SelectedValue = data.MemberId.ToString();               

                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtSavingsId.Text);
        var data = db.Savings.Where(d => d.SavingsId == x).FirstOrDefault();

        if (data != null)
        {
            txtAmount.Text = data.Amount.ToString();
            DropDownList2.SelectedValue = data.Type.ToString();
            txtDate.Text = data.Date.ToString();
            DropDownList3.SelectedValue = data.SavingsAccountNo.ToString();

            DropDownList1.SelectedValue = data.MemberId.ToString();
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtSavingsId.Text);
            var data = db.Savings.Where(d => d.SavingsId == x).FirstOrDefault();

            if (data != null)
            {
                data.SavingsId = Int32.Parse(txtSavingsId.Text);
                data.Amount = Decimal.Parse(txtAmount.Text);
                data.Type = DropDownList2.SelectedValue;
                data.Date = DateTime.Parse(txtDate.Text);
                data.SavingsAccountNo = Int32.Parse(DropDownList3.SelectedValue);


                data.MemberId = Int32.Parse(DropDownList1.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtSavingsId.Text);
            var data = db.Savings.Where(d => d.SavingsId == x).FirstOrDefault();

            if (data != null)
            {
                db.Savings.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }
}