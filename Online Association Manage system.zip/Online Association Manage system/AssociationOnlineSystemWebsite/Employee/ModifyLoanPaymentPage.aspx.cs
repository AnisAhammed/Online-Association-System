﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifyLoanPaymentPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Loans.ToList();
            DropDownList1.DataTextField = "LoanId";
            DropDownList1.DataValueField = "LoanId";
            DropDownList1.DataBind();

            DropDownList1.DataSource = db.Members.ToList();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "MemberId";
            DropDownList1.DataBind();

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.Loans.Where(d => d.LoanId == idn).FirstOrDefault();

                if (data != null)
                {
                    txtLoanPaymentNoId.Text = idn.ToString();
                    txtInstallmentNo.Text = ((Int32)data.LoanAmount).ToString();
                    txtInstallmentAmount.Text = data.InstallmentNo.ToString();                   
                    txtPaymentDate.Text = ((DateTime)data.LoanDate).ToString("yyyy / MM / dd");
                    DropDownList1.SelectedValue = data.LoanId.ToString();

                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtLoanPaymentNoId.Text);
        var data = db.LoanPayments.Where(d => d.LoanPaymentNoId == x).FirstOrDefault();

        if (data != null)
        {
            txtLoanPaymentNoId.Text = data.LoanPaymentNoId.ToString();
            txtInstallmentNo.Text = data.InstallmentNo.ToString();
            txtInstallmentAmount.Text = data.InstallmentAmount.ToString();
            txtPaymentDate.Text = data.PaymentDate.ToString();

            DropDownList1.SelectedValue = data.LoanId.ToString();
            
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtLoanPaymentNoId.Text);
            var data = db.LoanPayments.Where(d => d.LoanPaymentNoId == x).FirstOrDefault();

            if (data != null)
            {
                data.LoanPaymentNoId = Int32.Parse(txtLoanPaymentNoId.Text);
                data.InstallmentNo = Int32.Parse(txtInstallmentNo.Text);
                data.InstallmentAmount = decimal.Parse(txtInstallmentAmount.Text);
                data.PaymentDate = DateTime.Parse(txtPaymentDate.Text);


                data.LoanId = Int32.Parse(DropDownList1.SelectedValue);
                

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtLoanPaymentNoId.Text);
            var data = db.LoanPayments.Where(d => d.LoanPaymentNoId == x).FirstOrDefault();

            if (data != null)
            {
                db.LoanPayments.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }
}