﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifyTransactionPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.MAccounts.ToList();
            DropDownList1.DataTextField = "AccountNo";
            DropDownList1.DataValueField = "AccountNo";
            DropDownList1.DataBind();

            DropDownList3.DataSource = db.Members.ToList();
            DropDownList3.DataTextField = "FirstName";
            DropDownList3.DataValueField = "MemberId";
            DropDownList3.DataBind();

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.Transactions.Where(d => d.TransactionId == idn).FirstOrDefault();

                if (data != null)
                {
                    txtTransactionId.Text = idn.ToString();
                    txtAmount.Text = ((decimal)data.Amount).ToString(".00");
                    DropDownList4.SelectedValue = data.Type.ToString();                   
                    txtDate.Text = ((DateTime)data.Date).ToString("yyyy / MM / dd");
                    DropDownList1.SelectedValue = data.AccountNo.ToString();
                    DropDownList3.SelectedValue = data.MemberId.ToString();

                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
        
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtTransactionId.Text);
        var data = db.Transactions.Where(d => d.TransactionId == x).FirstOrDefault();

        if (data != null)
        {
            txtAmount.Text = data.Amount.ToString();
            DropDownList4.SelectedValue = data.Type.ToString();
            txtDate.Text = data.Date.ToString();

            DropDownList1.SelectedValue = data.AccountNo.ToString();
            DropDownList3.SelectedValue = data.MemberId.ToString();
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtTransactionId.Text);
            var data = db.Transactions.Where(d => d.TransactionId == x).FirstOrDefault();

            if (data != null)
            {
                data.TransactionId = Int32.Parse(txtTransactionId.Text);
                data.Type = DropDownList4.SelectedValue;
                data.Amount = decimal.Parse(txtAmount.Text);


                data.AccountNo = Int32.Parse(DropDownList1.SelectedValue);
                data.MemberId = Int32.Parse(DropDownList3.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);

                txtTransactionId.Text = "";
                txtAmount.Text = "";
                DropDownList4.SelectedIndex = -1;
                txtDate.Text = "";
                DropDownList1.SelectedIndex = -1;
                DropDownList3.SelectedIndex = -1;
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtTransactionId.Text);
            var data = db.Transactions.Where(d => d.TransactionId == x).FirstOrDefault();

            if (data != null)
            {
                db.Transactions.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);

                txtTransactionId.Text = "";
                txtAmount.Text = "";
                DropDownList4.SelectedIndex = -1;
                txtDate.Text = "";
                DropDownList1.SelectedIndex = -1;
                DropDownList3.SelectedIndex = -1;
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    
}