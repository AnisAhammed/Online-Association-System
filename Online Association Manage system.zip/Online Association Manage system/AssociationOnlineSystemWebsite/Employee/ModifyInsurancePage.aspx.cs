﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifyInsurancePage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Members.ToList();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "MemberId";
            DropDownList1.DataBind();

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.Insurances.Where(d => d.InsuranceId == idn).FirstOrDefault();

                if (data != null)
                {
                    txtInsuranceId.Text = idn.ToString();
                    DropDownList2.SelectedValue = data.Type;
                    txtMonthlyAmount.Text = ((decimal)data.MonthlyAmount).ToString(".00");
                    txtTotalInsurance.Text = ((decimal)data.TotalInsurance).ToString(".00");
                    txtTotalGetInsurance.Text = ((decimal)data.TotalGetInsurance).ToString(".00");
                    txtStartDate.Text = ((DateTime)data.InsuranceStartDate).ToString("yyyy / MM / dd");
                    txtEndDate.Text = ((DateTime)data.InsuranceEndDate).ToString("yyyy / MM / dd");
                    lblStatus.Text = data.Status;
                    DropDownList1.SelectedValue = data.MemberId.ToString();


                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtInsuranceId.Text);
        var data = db.Insurances.Where(d => d.InsuranceId == x).FirstOrDefault();

        if (data != null)
        {
            DropDownList2.SelectedValue = data.Type;
            txtMonthlyAmount.Text = ((decimal)data.MonthlyAmount).ToString(".00");
            txtTotalInsurance.Text = ((decimal)data.TotalInsurance).ToString(".00");
            txtTotalGetInsurance.Text = ((decimal)data.TotalGetInsurance).ToString(".00");
            txtStartDate.Text = ((DateTime)data.InsuranceStartDate).ToString("yyyy / MM / dd");
            txtEndDate.Text = ((DateTime)data.InsuranceEndDate).ToString("yyyy / MM / dd");
            lblStatus.Text = data.Status;
            DropDownList1.SelectedValue = data.MemberId.ToString();
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtInsuranceId.Text);
            var data = db.Insurances.Where(d => d.InsuranceId == x).FirstOrDefault();

            if (data != null)
            {
                //data.InsuranceId = Int32.Parse(txtInsuranceId.Text);
                //data.InsuranceAmount = Decimal.Parse(txtInsuranceAmount.Text);
                //data.InsuranceDate = DateTime.Parse(txtInsuranceDate.Text);
                //data.Type = txtType.Text;


                data.MemberId = Int32.Parse(DropDownList1.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }

    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtInsuranceId.Text);
            var data = db.Insurances.Where(d => d.InsuranceId == x).FirstOrDefault();

            if (data != null)
            {
                db.Insurances.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }
}