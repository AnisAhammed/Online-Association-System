﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_InsurancePaymentInsertPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("./Default.aspx");
        }

        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Insurances.Where(m => m.Status != "Not Approved").ToList();
            DropDownList1.DataTextField = "InsuranceId";
            DropDownList1.DataValueField = "InsuranceId";
            DropDownList1.DataBind();

            txtInsuranceDate.Text = DateTime.Now.ToShortDateString();
        }


    }
    protected void btnInsert_Click(object sender, EventArgs e)
    {
        try {
            InsurancePayment insp = new InsurancePayment();
           
                insp.MonthlyAmount = decimal.Parse(txtMonthlyAmount.Text);
                //insp.Amount = decimal.Parse(lblAmount.Text);
                insp.TotalInsurance = decimal.Parse(txtTotalInsurance.Text);
                insp.IPaymentDate = DateTime.Parse(txtInsuranceDate.Text);
                

            insp.InsuranceId = Int32.Parse(DropDownList1.SelectedValue);

            insp.UserName = Session["un"].ToString();

            db.InsurancePayments.Add(insp);
            db.SaveChanges();

            lblInsurancePaymentNo.Text = insp.IPaymentNo.ToString();

            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Save Successfully!!!')", true);

            lblInsurancePaymentNo.Text = "";           
            txtInsuranceDate.Text = "";
            txtMonthlyAmount.Text = "";
            txtTotalInsurance.Text = "";
           
        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Int32.Parse(DropDownList1.SelectedValue);
        var data = db.Insurances.Where(d => d.InsuranceId == id).FirstOrDefault();
        //var data1 = db.t.Where(d => d.InsuranceId == id).FirstOrDefault();

        if (data != null)
        {
            lblId.Text = id.ToString();
            lblType.Text = data.Type;
            lblMonthlyAmount.Text = ((decimal)data.MonthlyAmount).ToString(".00");
            lblTotalInsurance.Text = ((decimal)data.TotalInsurance).ToString(".00");
            lblTotalGetInsurance.Text = ((decimal)data.TotalGetInsurance).ToString(".00");
            lblStartDate.Text = ((DateTime)data.InsuranceStartDate).ToString("yyyy / MM / dd");
            lblEndDate.Text = ((DateTime)data.InsuranceEndDate).ToString("yyyy / MM / dd");
            txtMonthlyAmount.Text = ((decimal)data.MonthlyAmount).ToString(".00");
            txtTotalInsurance.Text = ((decimal)data.TotalInsurance).ToString(".00");
        }
    }

    protected void txtInsuranceAmount_TextChanged(object sender, EventArgs e)
    {
        //txtMonthlyAmount.Text = ((decimal.Parse(txtMonthlyAmount.Text)) + (decimal.Parse(txtAmount.Text))).ToString();
        
    }
}