﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_SavingsInsertPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("./Default.aspx");
        }

        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Members.Where(m => m.Status != "Not Approved").ToList();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "MemberId";
            DropDownList1.DataBind();

            

            txtDate.Text = DateTime.Now.ToShortDateString();
        }
        
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        try
        {
            Saving sa = new Saving();

                sa.Amount = decimal.Parse(txtAmount.Text);
                sa.Type = DropDownList2.SelectedValue;
                sa.Date = DateTime.Parse(txtDate.Text);
            sa.SavingsAccountNo = Int32.Parse(lblSavingsAccountNo.Text);
            sa.MemberId = Int32.Parse(DropDownList1.SelectedValue);

            sa.UserName = Session["un"].ToString();

            db.Savings.Add(sa);
            db.SaveChanges();

            lblSavingsId.Text = sa.SavingsId.ToString();

            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Save Successfully!!!')", true);

            lblSavingsId.Text = "";
            txtAmount.Text = "";
            DropDownList2.SelectedIndex = -1;
            txtDate.Text = "";        
            DropDownList1.SelectedIndex = -1;
            lblSavingsAccountNo.Text = "";

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Int32.Parse(DropDownList1.SelectedValue);
        var data = db.MSavingsPs.Where(d => d.MemberId == id).FirstOrDefault();

        if (data != null)
        {
            lblId.Text = id.ToString();
            lblFirstName.Text = data.FirstName + " " + data.LastName;
            lblPhoneNo.Text = data.Phone;
            Image1.ImageUrl = "../Upload/" + data.Photo;
            lblTotalSaving.Text = ((decimal)data.TotalSavings).ToString(".00");
            lblSavingsAccountNo.Text = data.SavingsAccountNo.ToString();
           
        }
        
    }
}