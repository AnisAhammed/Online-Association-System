﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modify_Member_Page : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Branches.ToList();
            DropDownList1.DataTextField = "Name";
            DropDownList1.DataValueField = "BranchId";
            DropDownList1.DataBind();

            

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.Members.Where(d => d.MemberId == idn).FirstOrDefault();

                if (data != null)
                {
                    txtMemberId.Text = idn.ToString();
                    txtFirstName.Text = data.FirstName;
                    txtLastName.Text = data.LastName;
                    txtFatherName.Text = data.FatherName;
                    txtMotherName.Text = data.MotherName;
                    txtDOB.Text = ((DateTime)data.DOB).ToString("yyyy / MM / dd");
                    RadioButtonList1.Text = data.Gender;
                    txtAddress.Text = data.Address;
                    txtPhone.Text = data.Phone;
                    Image1.ImageUrl = "../Upload/" + data.Photo;
                    txtNationalIdNo.Text = data.NIdNo;
                    txtPhone.Text = data.Phone;
                    lblMRegFee.Text = data.MRegFee.ToString();
                    txtAddress.Text = data.Address;
                    lblStatus.Text = data.Status;
                    DropDownList1.SelectedValue = data.BranchId.ToString();


                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtMemberId.Text);
        var data = db.Members.Where(d => d.MemberId == x).FirstOrDefault();

        if (data != null)
        {
           
            txtFirstName.Text = data.FirstName;
            txtLastName.Text = data.LastName;
            txtFatherName.Text = data.FatherName;
            txtMotherName.Text = data.MotherName;
            txtDOB.Text = data.DOB.ToString();
            RadioButtonList1.Text = data.Gender;
            Image1.ImageUrl = "../Upload/" + data.Photo;
            txtNationalIdNo.Text = data.NIdNo;
            txtPhone.Text = data.Phone;
            lblMRegFee.Text = data.MRegFee.ToString();
            txtAddress.Text = data.Address;
            lblStatus.Text = data.Status;

            DropDownList1.SelectedValue = data.BranchId.ToString();

            
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int idn = Int32.Parse(txtMemberId.Text);
            var data = db.Members.Where(d => d.MemberId == idn).FirstOrDefault();

            if (data != null)
            {
                data.MemberId = Int32.Parse(txtMemberId.Text);
                data.FirstName = txtFirstName.Text;
                data.LastName = txtLastName.Text;
                data.FatherName = txtFatherName.Text;
                data.MotherName = txtMotherName.Text;
                data.DOB = DateTime.Parse(txtDOB.Text);
                data.Gender = RadioButtonList1.Text;
                if (FileUpload1.HasFile)
                {
                    string extension = System.IO.Path.GetExtension(FileUpload1.FileName);

                    Session["Pic"] = FileUpload1.FileName;

                    if (extension == ".jpg" || extension == ".gif")
                    {
                        if (FileUpload1.PostedFile.ContentLength < (500 * 1024))
                        {
                            FileUpload1.SaveAs(Server.MapPath("../Upload/") + Session["pic"]);

                            Image1.ImageUrl = "../Upload/" + Session["pic"];
                        }
                        else
                        {
                            Literal1.Text = "<script>alert('Please select below 500 Kb !!!');</script>";
                            return;
                        }
                    }
                    else
                    {
                        Literal1.Text = "<script>alert('Please select jpg or gif file !!!');</script>";
                        return;
                    }

                }
                data.NIdNo = txtNationalIdNo.Text;
                data.Phone = txtPhone.Text;
                data.MRegFee = Decimal.Parse(lblMRegFee.Text);
                data.Address = txtAddress.Text;
                data.Status = lblStatus.Text;

                data.BranchId = Int32.Parse(DropDownList1.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);

                //Response.Redirect("./Default.aspx");    
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int idn = Int32.Parse(txtMemberId.Text);
            var data = db.Members.Where(d => d.MemberId == idn).FirstOrDefault();

            if (data != null)
            {
                db.Members.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }
}