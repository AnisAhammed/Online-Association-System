﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_ModifyInsurancePaymentPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.DataSource = db.Insurances.ToList();
            DropDownList1.DataTextField = "InsuranceId";
            DropDownList1.DataValueField = "InsuranceId";
            DropDownList1.DataBind();

            try
            {
                int idn = Int32.Parse(Request.QueryString["id"]);

                var data = db.InsurancePayments.Where(d => d.IPaymentNo == idn).FirstOrDefault();

                if (data != null)
                {
                    txtInsurancePaymentNo.Text = idn.ToString();
                    txtInsuranceAmount.Text = ((decimal)data.MonthlyAmount).ToString(".00");
                    txtAmount.Text = ((decimal)data.Amount).ToString(".00");
                    txtTotalAmount.Text = ((decimal)data.TotalInsurance).ToString(".00");
                    txtIPaymentDate.Text = ((DateTime)data.IPaymentDate).ToString("yyyy / MM / dd");
                    DropDownList1.SelectedValue = data.InsuranceId.ToString();

                    Literal1.Text = "";
                }
            }
            catch (Exception)
            {

            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        int x = Int32.Parse(txtInsurancePaymentNo.Text);
        var data = db.InsurancePayments.Where(d => d.IPaymentNo == x).FirstOrDefault();

        if (data != null)
        {
            txtInsuranceAmount.Text = data.MonthlyAmount.ToString();
            txtAmount.Text = data.Amount.ToString();
            txtTotalAmount.Text = data.TotalInsurance.ToString();
            txtIPaymentDate.Text = data.IPaymentDate.ToString();

            DropDownList1.SelectedValue = data.InsuranceId.ToString();
        }
        else
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Not Found!!!')", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtInsurancePaymentNo.Text);
            var data = db.InsurancePayments.Where(d => d.IPaymentNo == x).FirstOrDefault();

            if (data != null)
            {
                data.IPaymentNo = Int32.Parse(txtInsurancePaymentNo.Text);
                data.MonthlyAmount = Decimal.Parse(txtInsuranceAmount.Text);
                data.Amount = Decimal.Parse(txtAmount.Text);
                data.TotalInsurance = Decimal.Parse(txtTotalAmount.Text);
                data.IPaymentDate = DateTime.Parse(txtIPaymentDate.Text);


                data.InsuranceId = Int32.Parse(DropDownList1.SelectedValue);

                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Update Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            int x = Int32.Parse(txtInsurancePaymentNo.Text);
            var data = db.InsurancePayments.Where(d => d.IPaymentNo == x).FirstOrDefault();

            if (data != null)
            {
                db.InsurancePayments.Remove(data);
                db.SaveChanges();

                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Record Delete Successfully!!!')", true);
            }

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;

        }
    }
}