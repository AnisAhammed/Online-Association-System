﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_LoanPaymentInsertPage : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["un"] == null)
        {
            Response.Redirect("./Default.aspx");
        }

        if (!IsPostBack)
        {
            DropDownList2.DataSource = db.Members.Where(m => m.Status != "Not Approved").ToList();
            DropDownList2.DataTextField = "FirstName";
            DropDownList2.DataValueField = "MemberId";
            DropDownList2.DataBind();


            

            txtPaymentDate.Text = DateTime.Now.ToShortDateString();
        }

    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        try
        {
            LoanPayment lnpt = new LoanPayment();

                lnpt.InstallmentNo = Int32.Parse(txtInstallmentNo.Text);
                lnpt.InstallmentAmount = decimal.Parse(txtInstallmentAmount.Text);
                lnpt.PaymentDate = DateTime.Parse(txtPaymentDate.Text);
                lnpt.LoanId = Int32.Parse(lblLoanId1.Text);

            lnpt.UserName = Session["un"].ToString();

            db.LoanPayments.Add(lnpt);
            db.SaveChanges();

            lblLPNo.Text = lnpt.LoanPaymentNoId.ToString();

            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Data Save Successfully!!!')", true);

            lblLPNo.Text = "";
            txtInstallmentNo.Text = "";
            txtInstallmentAmount.Text = "";
            txtPaymentDate.Text = "";
            lblLoanId1.Text = "";
            

        }
        catch (Exception ex1)
        {

            Literal1.Text = ex1.Message;
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Int32.Parse(DropDownList2.SelectedValue);
        var data = db.MLoanPs.Where(d => d.MemberId == id).FirstOrDefault();

        if (data != null)
        {
            lblId.Text = id.ToString();
            lblFirstName.Text = data.FirstName + " " + data.LastName;
            lblPhoneNo.Text = data.Phone;
            Image1.ImageUrl = "../Upload/" + data.Photo;
            lblLoanId.Text = data.LoanId.ToString();
            lblLoanId1.Text = data.LoanId.ToString();
            txtInstallmentAmount.Text = ((decimal)data.InstallmentAmount).ToString(".00");
        }
    }
}