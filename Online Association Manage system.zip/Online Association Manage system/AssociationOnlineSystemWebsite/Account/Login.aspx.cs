﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Account_Login : System.Web.UI.Page
{
    ProjectDatabaseEntities2 db = new ProjectDatabaseEntities2();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogIn_Click(object sender, EventArgs e)
    {
        var data = db.Users.Where(d => d.UserName == txtUserName.Text && d.Password == txtPassword.Text).FirstOrDefault();
        if (data != null)
        {
            Session["un"] = txtUserName.Text;

            if (data.Type.ToUpper() == "Member".ToUpper())
            {
                Response.Redirect("../Member/Default.aspx");
            }
            else if (data.Type.ToUpper() == "Employee".ToUpper())
            {
                Response.Redirect("../Employee/Default.aspx");
            }
            else if (data.Type.ToUpper() == "Manager".ToUpper())
            {
                Response.Redirect("../Manager/Default.aspx");
            }
            

        }
        else
        {
            Literal1.Text = "<script>alert('Invalid username or password !!!');</script>";
            
        }
        Literal1.Text = "<script>alert('Invalid username or password !!!');</script>";

        txtUserName.Text = "";
        txtPassword.Text = "";
    }
}