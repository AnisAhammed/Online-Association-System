﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();


        mail.To.Add("diitidb@gmail.com");


        mail.From = new System.Net.Mail.MailAddress("diitidb@gmail.com", "Admin", System.Text.Encoding.UTF8);
        mail.Subject = btnName.Text + " " + txtFrom.Text;
        mail.SubjectEncoding = System.Text.Encoding.UTF8;
        mail.Body = txtMessage.Text;
        mail.BodyEncoding = System.Text.Encoding.UTF8;
        mail.IsBodyHtml = true;
        mail.Priority = System.Net.Mail.MailPriority.High;

        System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
        client.Credentials = new System.Net.NetworkCredential("diitidb@gmail.com", "round-27");
        client.Port = 587;
        client.Host = "smtp.gmail.com";
        client.EnableSsl = true;
        try
        {
            client.Send(mail);
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Email sent')", true);

        }
        catch (Exception ex)
        {

        }
    }
}